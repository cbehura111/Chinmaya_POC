/*
 * Copyright The OpenZipkin Authors
 * SPDX-License-Identifier: Apache-2.0
 */
export const CRITERION_BOX_HEIGHT = 34;
