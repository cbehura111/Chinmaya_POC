import type { Messages } from '@lingui/core';
          declare const messages: Messages;
          export { messages };
          