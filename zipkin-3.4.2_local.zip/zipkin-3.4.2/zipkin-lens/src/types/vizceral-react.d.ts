/*
 * Copyright The OpenZipkin Authors
 * SPDX-License-Identifier: Apache-2.0
 */
declare module 'vizceral-react' {
  export default class extends React.Component<any, any> {
    public vizceral: any;
  }
}
