/*
 * Copyright The OpenZipkin Authors
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Classes in this package are considered internal details to Zipkin's server and are unsupported
 * unless integrated with our server build.
 */
package zipkin2.server.internal;
